from bookshop_app import app
from bookshop_app.controllers import authors

if __name__ == "__main__":
    app.run(debug=True)